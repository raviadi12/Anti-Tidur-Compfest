# Anti-Tidur

an image classifier application that was developed with flutter.
this app classifies about the differences of leaf that build with MobileNet as it's pre-trained model.
