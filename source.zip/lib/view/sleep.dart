import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_audio_capture/flutter_audio_capture.dart';
import 'package:iirjdart/butterworth.dart';
import 'dart:async';
import 'dart:math';
import 'package:vibration/vibration.dart';

final player = AudioPlayer();

class SleepSound extends StatefulWidget {
  const SleepSound({Key? key}) : super(key: key);

  @override
  _SleepSoundState createState() => _SleepSoundState();
}

class _SleepSoundState extends State<SleepSound> {
  bool _isRecording = false;
  List<double> _decibelsHistory = [];
  static const int maxHistoryLength = 100;
  double _dbThreshold = 70.0; // Default threshold value in dB
  late FlutterAudioCapture _audioCapture;
  late Butterworth _butterworth;
  StreamSubscription<dynamic>? _audioStreamSubscription;
  double _progress = 0.0; // Progress bar value
  static const int progressIncrement = 1; // Progress increment value
  late Timer _progressTimer;
  double _interval = 500;

  @override
  void initState() {
    super.initState();
    _audioCapture = FlutterAudioCapture();
    _butterworth = Butterworth();

    _initRecorder();
  }

  Future<void> _initRecorder() async {
    if (await Permission.microphone.request().isGranted) {
      print("Microphone permission granted");
    } else {
      print("Microphone permission denied");
    }
  }

  void startRecording() async {
    setState(() {
      _isRecording = true;
    });

    _butterworth.highPass(4, 44100,
        250); // 4th order Butterworth high-pass filter, cutoff frequency 250 Hz

    _audioCapture.start(
      _captureHandler,
      _onError,
      sampleRate: 44100,
      bufferSize: 3000,
    );

    print("Recording started");

    // Start the progress timer
    _startProgressTimer();
  }

  void _startProgressTimer() {
    _progressTimer =
        Timer.periodic(Duration(milliseconds: _interval.toInt()), (timer) {
      if (_progress >= 100) {
        _triggerFullProgressAction();
      } else {
        setState(() {
          _progress += progressIncrement;
        });
      }
    });
  }

  void _triggerFullProgressAction() async {
    print("Progress bar is full! Triggering action...");
    _stopAllActivities();
    Vibration.vibrate(duration: 1000); // Vibrate the device for 1 second
    await player.setLoopMode(LoopMode.one); // Set the player to loop the audio
    await player.setAsset('assets/warn.mp3'); // Set the audio file
    player.play(); // Start playing the warning sound

    // Show the popup modal
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Inactivity Detected'),
          content: Text(
              'Inactivity detected from you, now please close this button to turn off the alarm'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _resumeAllActivities();
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _stopAllActivities() {
    stopRecording();
    player.stop();
    _resetProgress();
  }

  void _resumeAllActivities() {
    startRecording();
    player.stop();
  }

  void _resetProgress() {
    setState(() {
      _progress = 0.0;
    });
  }

  void _captureHandler(dynamic data) async {
    List<double> audioData = List<double>.from(data);

    // Apply high-pass filter
    List<double> filteredData =
        audioData.map((sample) => _butterworth.filter(sample)).toList();

    // Calculate the decibel level
    double decibel = _calculateDecibel(filteredData);
    decibel += 100;
    print('Filtered Noise: $decibel dB');

    setState(() {
      _decibelsHistory.add(decibel);
      if (_decibelsHistory.length > maxHistoryLength) {
        _decibelsHistory.removeAt(0);
      }
    });

    // Reset progress if decibel level exceeds threshold
    if (decibel >= _dbThreshold) {
      _resetProgress();
    }
  }

  void _onError(Object error) {
    print(error.toString());
    setState(() {
      _isRecording = false;
    });
  }

  double _calculateDecibel(List<double> audioData) {
    double sum = 0.0;
    for (double sample in audioData) {
      sum += sample * sample;
    }
    double rms = sqrt(sum / audioData.length);
    double decibel = 20 * (log(rms) / ln10); // Convert natural log to base 10
    return decibel;
  }

  void stopRecording() async {
    setState(() {
      _isRecording = false;
    });
    await _audioCapture.stop();
    _audioStreamSubscription?.cancel();
    _progressTimer.cancel();
  }

  @override
  void dispose() {
    _audioStreamSubscription?.cancel();
    _progressTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Set background color to black
      appBar: AppBar(
        title: const Text(
          'Virtual Deadman Pedal',
          style: TextStyle(
            color: Colors.white, // Set text color to white
            fontFamily: 'Montserrat', // Use the Montserrat font family
            fontWeight: FontWeight.bold, // Use bold font weight
          ),
        ),
        backgroundColor: Colors.black,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _isRecording ? stopRecording : startRecording,
              child: Text(
                _isRecording ? 'Stop Recording' : 'Start Recording',
                style: const TextStyle(
                  color:
                      Color.fromARGB(255, 54, 0, 85), // Set text color to white
                  fontFamily: 'Montserrat', // Use the Montserrat font family
                  fontWeight: FontWeight.bold, // Use bold font weight
                ),
              ),
            ),
            SizedBox(height: 20),
            SizedBox(
              height: 200,
              width: double.infinity,
              child: CustomPaint(
                painter: DecibelMeterPainter(_decibelsHistory, _dbThreshold),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Threshold: ${_dbThreshold.toStringAsFixed(1)} dB',
              style: const TextStyle(
                color: Colors.white, // Set text color to white
                fontFamily: 'Montserrat', // Use the Montserrat font family
                fontWeight: FontWeight.bold, // Use bold font weight
              ),
            ),
            Slider(
              value: _dbThreshold,
              min: 30,
              max: 100,
              divisions: 70,
              label: _dbThreshold.toStringAsFixed(1),
              onChanged: (double value) {
                setState(() {
                  _dbThreshold = value;
                });
              },
            ),
            Text(
              'Progress Bar buildup: ${_interval.toStringAsFixed(1)} ms',
              style: const TextStyle(
                color: Colors.white, // Set text color to white
                fontFamily: 'Montserrat', // Use the Montserrat font family
                fontWeight: FontWeight.bold, // Use bold font weight
              ),
            ),
            Slider(
              value: _interval,
              min: 100,
              max: 1000,
              divisions: 9,
              label: _interval.toStringAsFixed(1),
              onChanged: (double value) {
                setState(() {
                  _interval = value;
                });
              },
            ),
            SizedBox(height: 20),
            LinearProgressIndicator(
              value: _progress / 100,
            ),
            SizedBox(height: 20),
            Text(
              'Progress: ${_progress.toStringAsFixed(1)}%',
              style: const TextStyle(
                color: Colors.white, // Set text color to white
                fontFamily: 'Montserrat', // Use the Montserrat font family
                fontWeight: FontWeight.bold, // Use bold font weight
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DecibelMeterPainter extends CustomPainter {
  final List<double> decibelsHistory;
  final double dbThreshold;

  DecibelMeterPainter(this.decibelsHistory, this.dbThreshold);

  @override
  void paint(Canvas canvas, Size size) {
    final Paint backgroundPaint = Paint()
      ..color = Color.fromARGB(255, 19, 95, 0);
    final Paint linePaint = Paint()
      ..color = Color.fromARGB(255, 255, 129, 238)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;
    final Paint thresholdPaint = Paint()
      ..color = Colors.red
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    canvas.drawRect(
        Rect.fromLTWH(0, 0, size.width, size.height), backgroundPaint);

    if (decibelsHistory.isEmpty) {
      return; // Nothing to draw
    }

    final double maxDecibel = 120.0;
    final double minDecibel = 0.0;

    for (int i = 0; i < decibelsHistory.length - 1; i++) {
      final double x1 = (i / (decibelsHistory.length - 1)) * size.width;
      final double y1 = size.height -
          ((decibelsHistory[i] - minDecibel) / (maxDecibel - minDecibel)) *
              size.height;
      final double x2 = ((i + 1) / (decibelsHistory.length - 1)) * size.width;
      final double y2 = size.height -
          ((decibelsHistory[i + 1] - minDecibel) / (maxDecibel - minDecibel)) *
              size.height;

      canvas.drawLine(Offset(x1, y1), Offset(x2, y2), linePaint);
    }

    // Draw threshold line
    final double thresholdY = size.height -
        ((dbThreshold - minDecibel) / (maxDecibel - minDecibel)) * size.height;
    canvas.drawLine(
        Offset(0, thresholdY), Offset(size.width, thresholdY), thresholdPaint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
