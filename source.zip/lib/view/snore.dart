import 'dart:io';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:just_audio/just_audio.dart';
import 'package:get/get.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:math';
import 'dart:math' as math;
import 'package:vibration/vibration.dart';
import 'package:shared_preferences/shared_preferences.dart';

final player = AudioPlayer();

double root(num value, num rootDegree) {
  if (value is! num || rootDegree is! num) {
    throw ArgumentError('Must be a number');
  }
  if (rootDegree <= 0) {
    throw ArgumentError('Must be positive');
  }
  return math.pow(value, 1 / rootDegree).toDouble();
}

class SnoreScreen extends StatefulWidget {
  @override
  _SnoreScreenState createState() => _SnoreScreenState();
}

class _SnoreScreenState extends State<SnoreScreen> {
  late Future<void> _initializeControllerFuture;
  late CameraController _cameraController;
  late FaceDetector _faceDetector;
  bool isDetecting = false;
  bool frontCamera = false;

  double? leftEyeOpenProb;
  double? rightEyeOpenProb;
  double? smileProb;
  int? trackingId;
  List<Point<int>> landmarks = [];
  int _cameraIndex = 0;
  bool _isDarkMode = false;
  bool isPlaying = false;
  int threshold = 10;
  int currentProgress = 0;
  double activThreshold = 0.5;
  List<double> leftEyeHistory = [];
  List<double> rightEyeHistory = [];
  double cameraWidth = 0.0;
  double cameraHeight = 0.0;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _initializeFaceDetector();
  }

  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    _cameraController = CameraController(
      cameras[_cameraIndex],
      ResolutionPreset.medium,
      enableAudio: false,
      imageFormatGroup: Platform.isAndroid
          ? ImageFormatGroup.nv21
          : ImageFormatGroup.bgra8888,
    );
    _initializeControllerFuture = _cameraController.initialize();
    await _initializeControllerFuture;

    final camera = _cameraController.description;
    frontCamera = camera.lensDirection == CameraLensDirection.front;

    setState(() {
      cameraWidth = _cameraController.value.previewSize?.width ?? 0.0;
      cameraHeight = _cameraController.value.previewSize?.height ?? 0.0;
    });
  }

  void _switchCamera() async {
    final cameras = await availableCameras();
    _cameraIndex = (_cameraIndex + 1) % cameras.length;
    await _cameraController.dispose();
    _initializeCamera();
  }

  void _initializeFaceDetector() {
    final options = FaceDetectorOptions(
      enableContours: false,
      enableLandmarks: true,
      enableClassification: true,
    );
    _faceDetector = FaceDetector(options: options);
  }

  @override
  void dispose() {
    _cameraController.dispose();
    _faceDetector.close();
    super.dispose();
  }

  InputImage? _inputImageFromCameraImage(CameraImage image) {
    final camera = _cameraController.description;
    final sensorOrientation = camera.sensorOrientation;
    InputImageRotation? rotation;

    if (Platform.isIOS) {
      rotation = InputImageRotationValue.fromRawValue(sensorOrientation);
    } else if (Platform.isAndroid) {
      final rotationCompensation =
          _orientations[_cameraController.value.deviceOrientation] ?? 0;
      if (camera.lensDirection == CameraLensDirection.front) {
        rotation = InputImageRotationValue.fromRawValue(
            (sensorOrientation + rotationCompensation) % 360);
      } else {
        rotation = InputImageRotationValue.fromRawValue(
            (sensorOrientation - rotationCompensation + 360) % 360);
      }
    }

    if (rotation == null) return null;

    final format = InputImageFormatValue.fromRawValue(image.format.raw);
    if (format == null ||
        (Platform.isAndroid && format != InputImageFormat.nv21) ||
        (Platform.isIOS && format != InputImageFormat.bgra8888)) return null;

    final plane = image.planes.first;
    return InputImage.fromBytes(
      bytes: plane.bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  void _detectFaces(CameraImage image) async {
    if (isDetecting) return;
    isDetecting = true;

    final inputImage = _inputImageFromCameraImage(image);
    if (inputImage == null) {
      isDetecting = false;
      return;
    }

    final List<Face> faces = await _faceDetector.processImage(inputImage);

    if (faces.isNotEmpty) {
      final face = faces.first;

      double leftEyeOpenProbNorm =
          face.leftEyeOpenProbability ?? 1.0; // Default to 1.0 if null
      double rightEyeOpenProbNorm =
          face.rightEyeOpenProbability ?? 1.0; // Default to 1.0 if null

      leftEyeHistory.add(leftEyeOpenProbNorm);
      rightEyeHistory.add(rightEyeOpenProbNorm);
      if (leftEyeHistory.length > 50) leftEyeHistory.removeAt(0);
      if (rightEyeHistory.length > 50) rightEyeHistory.removeAt(0);

      if (leftEyeOpenProbNorm < activThreshold ||
          rightEyeOpenProbNorm < activThreshold) {
        if (currentProgress < threshold) {
          currentProgress++;
        }
      } else {
        if (currentProgress >= 0) {
          currentProgress -= 2;
        } else {
          currentProgress = 0;
        }
      }

      if (currentProgress == threshold) {
        Vibration.vibrate(duration: 1000); // Vibrate the device for 1 second
        if (!isPlaying) {
          await player
              .setLoopMode(LoopMode.one); // Set the player to loop the audio
          await player.setAsset('assets/warn.mp3'); // Set the audio file
          player.play(); // Start playing the warning sound
          isPlaying = true;

          // Increment sleep count and save to local storage
          SharedPreferences prefs = await SharedPreferences.getInstance();
          int sleepCount = (prefs.getInt('sleepCount') ?? 0) + 1;
          await prefs.setInt('sleepCount', sleepCount);
        }
      } else {
        player.stop();
        isPlaying = false;
      }

      setState(() {
        leftEyeOpenProb = face.leftEyeOpenProbability;
        rightEyeOpenProb = face.rightEyeOpenProbability;
        smileProb = face.smilingProbability;
        trackingId = face.trackingId;
        landmarks = [
          face.landmarks[FaceLandmarkType.bottomMouth]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.leftMouth]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.rightMouth]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.leftEye]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.rightEye]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.noseBase]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.rightCheek]?.position ?? Point(0, 0),
          face.landmarks[FaceLandmarkType.leftCheek]?.position ?? Point(0, 0),
        ];
      });
    }

    isDetecting = false;
  }

  void _toggleDarkMode() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  void _showSettingsModal() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Container(
              padding: EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Settings',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Delay before Alarm Activates',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                  Slider(
                    value: threshold.toDouble(),
                    max: 20.0,
                    min: 2.0,
                    divisions: 9,
                    label: threshold.toString(),
                    onChanged: (value) {
                      setModalState(() {
                        threshold = value.toInt();
                      });
                      setState(
                          () {}); // Ensure the parent state is updated as well
                    },
                  ),
                  Text(
                    'Activation Threshold',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                  Slider(
                    value: activThreshold,
                    max: 1.0,
                    min: 0.1,
                    divisions: 9,
                    label: activThreshold.toString(),
                    onChanged: (value) {
                      setModalState(() {
                        activThreshold = value;
                      });
                      setState(
                          () {}); // Ensure the parent state is updated as well
                    },
                  ),
                  // Add sliders or other settings components here
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Sleepiness Detection (new)',
          style: TextStyle(
            color: _isDarkMode ? Colors.white : Colors.black,
            fontFamily: 'Montserrat',
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: _isDarkMode ? Colors.black : Colors.white,
        actions: [
          IconButton(
            icon: Icon(_isDarkMode ? Icons.wb_sunny : Icons.nights_stay),
            onPressed: _toggleDarkMode,
          ),
          IconButton(
            icon: Icon(Icons.switch_camera),
            onPressed: _switchCamera,
          ),
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: _showSettingsModal,
          ),
        ],
      ),
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            _cameraController.startImageStream((image) => _detectFaces(image));
            return Stack(
              children: [
                CameraPreview(_cameraController),
                Positioned(
                  bottom: 50,
                  left: 10,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Left Eye (Red):      ',
                            style: TextStyle(
                              color: _isDarkMode ? Colors.white : Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Container(
                            width: 20,
                            height: 20 * (leftEyeOpenProb ?? 0.01),
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage('assets/eye_icon.png'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            'Right Eye (Green): ',
                            style: TextStyle(
                              color: _isDarkMode ? Colors.white : Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Container(
                            width: 20,
                            height: 20 * (rightEyeOpenProb ?? 0.01),
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage('assets/eye_icon.png'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width * 0.5,
                        child: LinearProgressIndicator(
                          value: currentProgress / threshold,
                          backgroundColor: Colors.grey,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                        ),
                      ),
                    ],
                  ),
                ),
                CustomPaint(
                  size: Size.infinite,
                  painter:
                      LandmarkPainter(landmarks, frontCamera, cameraHeight),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color.fromARGB(255, 84, 0, 105),
                    child: CustomPaint(
                      painter:
                          HistoryGraphPainter(leftEyeHistory, rightEyeHistory),
                    ),
                  ),
                ),
                ...landmarks.map((landmark) {
                  return Positioned(
                    left: frontCamera
                        ? 370 - root(landmark.x, 1.05).toDouble()
                        : root(landmark.x, 1.05).toDouble(),
                    top: root(landmark.y, 1.05).toDouble() +
                        20 * (landmark.y / cameraHeight),
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 255, 0, 0),
                        shape: BoxShape.circle,
                      ),
                    ),
                  );
                }).toList(),
              ],
            );
          } else {
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
      backgroundColor: _isDarkMode ? Colors.black : Colors.white,
    );
  }
}

const _orientations = {
  DeviceOrientation.portraitUp: 0,
  DeviceOrientation.landscapeLeft: 90,
  DeviceOrientation.portraitDown: 180,
  DeviceOrientation.landscapeRight: 270,
};

class LandmarkPainter extends CustomPainter {
  final List<Point<int>> landmarks;
  final bool frontCamera;
  double cameraHeight;

  LandmarkPainter(this.landmarks, this.frontCamera, this.cameraHeight);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.green
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;

    // Draw lines connecting original landmarks
    for (int i = 0; i < landmarks.length; i++) {
      for (int j = i + 1; j < landmarks.length; j++) {
        final p1 = landmarks[i];
        final p2 = landmarks[j];

        final x1 = frontCamera
            ? 370 - root(p1.x, 1.05).toDouble()
            : root(p1.x, 1.05).toDouble();
        final y1 = root(p1.y, 1.05).toDouble() + 20 * (p1.y / cameraHeight);
        final x2 = frontCamera
            ? 370 - root(p2.x, 1.05).toDouble()
            : root(p2.x, 1.05).toDouble();
        final y2 = root(p2.y, 1.05).toDouble() + 20 * (p2.y / cameraHeight);

        canvas.drawLine(
          Offset(x1, y1),
          Offset(x2, y2),
          paint,
        );
      }
    }

    // Draw lines connecting offset points
    for (int i = 0; i < landmarks.length; i++) {
      for (int j = i + 1; j < landmarks.length; j++) {
        final p1 = landmarks[i];
        final p2 = landmarks[j];

        final offset = 40; // offset distance
        final angle1 = atan2(p1.y - p2.y, p1.x - p2.x);
        final angle2 = atan2(p2.y - p1.y, p2.x - p1.x);

        final offsetX1 = offset * cos(angle1);
        final offsetY1 = offset * sin(angle1);
        final offsetX2 = offset * cos(angle2);
        final offsetY2 = offset * sin(angle2);

        final x1 = frontCamera
            ? 370 - root(p1.x, 1.05).toDouble() - offsetX1
            : root(p1.x, 1.05).toDouble() + offsetX1;
        final y1 =
            root(p1.y, 1.05).toDouble() + 20 * (p1.y / cameraHeight) + offsetY1;
        final x2 = frontCamera
            ? 370 - root(p2.x, 1.05).toDouble() - offsetX2
            : root(p2.x, 1.05).toDouble() + offsetX2;
        final y2 =
            root(p2.y, 1.05).toDouble() + 20 * (p2.y / cameraHeight) + offsetY2;

        canvas.drawLine(
          Offset(x1, y1),
          Offset(x2, y2),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return oldDelegate != this;
  }
}

class HistoryGraphPainter extends CustomPainter {
  final List<double> leftEyeData;
  final List<double> rightEyeData;

  HistoryGraphPainter(this.leftEyeData, this.rightEyeData);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final pathLeft = Path();
    final pathRight = Path();

    double widthStep = size.width / (leftEyeData.length - 1);

    pathLeft.moveTo(0, size.height * (1 - leftEyeData[0]));
    pathRight.moveTo(0, size.height * (1 - rightEyeData[0]));

    for (int i = 1; i < leftEyeData.length; i++) {
      pathLeft.lineTo(i * widthStep, size.height * (1 - leftEyeData[i]));
      pathRight.lineTo(i * widthStep, size.height * (1 - rightEyeData[i]));
    }

    paint.color = Colors.red;
    canvas.drawPath(pathLeft, paint);

    paint.color = Colors.green;
    canvas.drawPath(pathRight, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
