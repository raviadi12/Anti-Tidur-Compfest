import 'package:get/get.dart';
import 'package:simpleapp/controller/scan_controller.dart';
import 'package:simpleapp/view/camera_view.dart';
import 'package:simpleapp/view/dashboard.dart';
import 'package:simpleapp/view/sleep.dart'; // Import the SleepSound widget
import 'package:simpleapp/view/snore.dart'; // Import the SnoreScreen widget
import 'package:simpleapp/view/config.dart';

class AppRoutes {
  static final pages = [
    GetPage(
      transition: Transition.fadeIn,
      transitionDuration: const Duration(seconds: 2),
      name: '/home',
      page: () => const CameraView(),
    ),
    GetPage(
      transition: Transition.fadeIn,
      transitionDuration: const Duration(seconds: 2),
      name: '/config',
      page: () => const ConfigPage(),
    ),
    GetPage(
      transition: Transition.fadeIn,
      transitionDuration: const Duration(seconds: 2),
      name: '/snore', // Update this route name
      page: () => const SleepSound(), // Navigate to the SleepSound widget
    ),
    GetPage(
      transition: Transition.fadeIn,
      transitionDuration: const Duration(seconds: 2),
      name: '/face', // Update this route name
      page: () => SnoreScreen(), // Navigate to the SleepSound widget
    ),
    GetPage(
        transition: Transition.downToUp,
        transitionDuration: const Duration(seconds: 2),
        name: '/dashboard',
        page: () => DashBoard(),
        binding: BindingsBuilder(() {
          Get.put(ScanController());
        }))
  ];
}
